from flask import *
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/active_chat'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)

@app.route('/home')
def home():
   return render_template("HOME.html")
@app.route('/login')
def login():
   return render_template("LOGIN.html")   
@app.route('/contact')
def contact():
   return render_template("CONTACT.html")
@app.route('/ucontact')
def ucontact():
   return render_template("UCONTACT.html")
@app.route('/about')
def about():
   return render_template("ABOUT.html")  
@app.route('/uabout')
def uabout():
   return render_template("UABOUT.html")   
@app.route('/signup')
def signup():
   return render_template("SIGNUP.html")
@app.route('/adminlogin')
def adminlogin():
   return render_template("ADMINLOGIN.html")  
@app.route('/keywords')
def keywords():
   return render_template("KEYWORDS.html",keywords=keywords.query.all())
@app.route('/check')
def check():
   return render_template("CHECK.html",signup=signup.query.all())   
@app.route('/block')
def block():
   return render_template("BLOCK.html",signup=signup.query.all())  
@app.route('/chatmaintain')
def chatmaintain():
   return render_template("CHATMAINTAIN.html")   
@app.route('/password')
def password():
   return render_template("PASSWORD.html")
@app.route('/view')
def view():
   return render_template("VIEW.html")  
@app.route('/viewuser')
def viewuser():
   return render_template("VIEWUSER.html",signup=signup.query.all())  
@app.route('/logout')
def logout():
   return render_template("LOGIN.html")
@app.route('/userlogin/<name>')
def userlogin(name):
   return render_template("USERLOGIN.html",signup=signup.query.filter_by(USERNAME='%s'%name))
@app.route('/checkuser/<name>')
def checkuser(name):
   return render_template("CHECKUSER.html",signup=signup.query.filter_by(USERNAME='%s'%name))
@app.route('/feedback')
def feedback():
   return render_template("FEEDBACK.html",ucontact=ucontact.query.all())  
@app.route('/settings')
def settings():
   return render_template("SETTINGS.html")   
@app.route('/contacts')
def contacts():
   return render_template("CONTACTS.html")
@app.route('/userhome')
def userhome():
   return render_template("USERHOME.html")
@app.route('/uchat')
def uchat():
   return render_template("UCHAT.html")
@app.route('/ucontacts')
def ucontacts():
   return render_template("UCONTACTS.html",ucontacts=ucontacts.query.all())



class signup(db.Model):
	id = db.Column('signu_id', db.Integer, primary_key = True)
	USERNAME = db.Column(db.String(100))
	PASSWORD = db.Column(db.String(200))
	CPASSWORD = db.Column(db.String(200)) 
	DOB = db.Column(db.String(100))
	EMAIL = db.Column(db.String(200))
	GENDER = db.Column(db.String(100))
	def __init__(self, USERNAME, PASSWORD, CPASSWORD, DOB, EMAIL, GENDER):
		self.USERNAME = USERNAME 
		self.PASSWORD = PASSWORD
		self.CPASSWORD = CPASSWORD
		self.DOB = DOB
		self.EMAIL = EMAIL
		self.GENDER = GENDER
	@app.route('/sign', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['USERNAME'] or not request.form['PASSWORD'] or not request.form['CPASSWORD'] or not request.form['DOB'] or not request.form['EMAIL'] or not request.form['GENDER']:
				flash('Please enter all the fields', 'error')
			else:
				signu = signup(request.form['USERNAME'], request.form['PASSWORD'],
				request.form['CPASSWORD'], request.form['DOB'], request.form['EMAIL'], request.form['GENDER'])
				db.session.add(signu)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('login'))
		return render_template('signup.html')
		
@app.route('/login', methods=['POST','GET'])
def loginn():
	if request.method=='GET':
		return render_template('LOGIN.html')
	USERNAME = request.form['USERNAME']
	PASSWORD = request.form['PASSWORD']
	session['USERNAME']=USERNAME
	signu=signup.query.filter_by(USERNAME=USERNAME,PASSWORD=PASSWORD).first()
	if request.form['PASSWORD'] == 'admin' and request.form['USERNAME'] == 'admin':
		return render_template("adminlogin.html")
	if signu is None:
		return render_template("LOGIN.html")
	else:
		return redirect(url_for("userlogin",name=USERNAME))
		
class contact(db.Model):
	id = db.Column('contact_id', db.Integer, primary_key = True)
	USERNAME = db.Column(db.String(100))
	EMAIL = db.Column(db.String(200))
	FEEDBACK = db.Column(db.String(200))
	def __init__(self, USERNAME, EMAIL, FEEDBACK): 
		self.USERNAME = USERNAME 
		self.EMAIL = EMAIL
		self.FEEDBACK = FEEDBACK
	@app.route('/contact', methods = ['GET', 'POST'])
	def contact1():
		if request.method == 'POST':
			if not request.form['USERNAME'] or not request.form['EMAIL'] or not request.form['FEEDBACK']:
				flash('Please enter all the fields', 'error')
			else:
				contacts = contact(request.form['USERNAME'], request.form['EMAIL'], request.form['FEEDBACK'])
				db.session.add(contacts)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('home'))
		return render_template('contact.html')	
		
		
class ucontact(db.Model):
	id = db.Column('ucontact_id', db.Integer, primary_key = True)
	NAME = db.Column(db.String(100))
	EMAIL = db.Column(db.String(200))
	MESSAGE = db.Column(db.String(200))
	def __init__(self, NAME, EMAIL, MESSAGE): 
		self.NAME = NAME 
		self.EMAIL = EMAIL
		self.MESSAGE = MESSAGE
	@app.route('/ucontact', methods = ['GET', 'POST'])
	def ucontact1():
		if request.method == 'POST':
			if not request.form['NAME'] or not request.form['EMAIL'] or not request.form['MESSAGE']:
				flash('Please enter all the fields', 'error')
			else:
				uucontact = ucontact(request.form['NAME'], request.form['EMAIL'], request.form['MESSAGE'])
				db.session.add(uucontact)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('ucontact'))
		return render_template('ucontact.html')

class keywords(db.Model):
	id = db.Column('keywords_id', db.Integer, primary_key = True)
	KEYWORDS = db.Column(db.String(1000))
	def __init__(self, KEYWORDS): 
		self.KEYWORDS = KEYWORDS 
	@app.route('/keywords', methods = ['GET', 'POST'])
	def keywords1():
		if request.method == 'POST':
			if not request.form['KEYWORDS']:
				flash('Please enter all the fields', 'error')
			else:
				keyword = keywords(request.form['KEYWORDS'])
				db.session.add(keyword)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('keywords'))
		return render_template('keywords.html')

		

	
@app.route('/CHECKUSER', methods=['POST','GET'])
def check1():
	if request.method=='GET':
		return render_template('CHECK.html')
	USERNAME = request.form['USERNAME']
	return redirect(url_for("checkuser",name=USERNAME))
	
	
@app.route('/status/<int:id>' , methods=['POST', 'GET'])
def status(id):
	signu=signup.query.filter_by(id=id).delete()
	db.session.commit()
	return redirect(url_for('block'))
	
		

		
# class block(db.Model):
	# id = db.Column('block_id', db.Integer, primary_key = True)
	# USERNAME = db.Column(db.String(1000))
	# EMAIL = db.Column(db.String(1000))
	# BLOCK_URL = db.Column(db.String(1000))
	# def __init__(self, USERNAME, EMAIL, BLOCK_URL): 
		# self.USERNAME = USERNAME 
		# self.EMAIL = EMAIL
		# self.BLOCK_URL = BLOCK_URL 
	# @app.route('/block', methods = ['GET', 'POST'])
	# def block1():
		# if request.method == 'POST':
			# if not request.form['USERNAME'] or not request.form['EMAIL'] or not request.form['BLOCK_URL']:
				# flash('Please enter all the fields', 'error')
			# else:
				# blocks = block(request.form['USERNAME'], request.form['EMAIL'],request.form['BLOCK_URL'])
				# db.session.add(blocks)
				# db.session.commit()
				# flash('Record was successfully added')
				# return redirect(url_for('adminlogin'))
		# return render_template('block.html')
		
		
		
# class ucontacts(db.Model):
	# id = db.Column('ucontact_id', db.Integer, primary_key = True)
	# UCONTACTS = db.Column(db.String(1000))
	# def __init__(self, UCONTACTS): 
		# self.UCONTACTS = UCONTACTS 
	# @app.route('/ucontacts', methods = ['GET', 'POST'])
	# def ucontacts1():
		# if request.method == 'POST':
			# if not request.form['UCONTACTS']:
				# flash('Please enter all the fields', 'error')
			# else:
				# ucontact = ucontacts(request.form['UCONTACTS'])
				# db.session.add(ucontact)
				# db.session.commit()
				# flash('Record was successfully added')
				# return redirect(url_for('ucontacts'))
		# return render_template('ucontacts.html')		
	
# class chat(db.Model):
	# id = db.Column('chat_id', db.Integer, primary_key = True)
	# USERNAME = db.Column(db.String(1000))
	# EMAIL = db.Column(db.String(1000))
	# def __init__(self, USERNAME, EMAIL): 
		# self.USERNAME = USERNAME 
		# self.EMAIL = EMAIL
	# @app.route('/chat', methods = ['GET', 'POST'])
	# def chat1():
		# if request.method == 'POST':
			# if not request.form['USERNAME'] or not request.form['EMAIL']:
				# flash('Please enter all the fields', 'error')
			# else:
				# chats = chat(request.form['USERNAME'], request.form['EMAIL'])
				# db.session.add(chats)
				# db.session.commit()
				# flash('Record was successfully added')
				# return redirect(url_for('view'))
		# return render_template('chatmaintain.html')
		
# class password(db.Model):
	# id = db.Column('password_id', db.Integer, primary_key = True)
	# USERNAME = db.Column(db.String(100))
	# OLDPASSWORD = db.Column(db.String(200))
	# NEWPASSWORD = db.Column(db.String(200))
	# CPASSWORD = db.Column(db.String(200))
	# def __init__(self, USERNAME, OLDPASSWORD, NEWPASSWORD, CPASSWORD ): 
		# self.USERNAME = USERNAME 
		# self.OLDPASSWORD = OLDPASSWORD
		# self.NEWPASSWORD = NEWPASSWORD
		# self.CPASSWORD = CPASSWORD
	# @app.route('/password', methods = ['GET', 'POST'])
	# def password1():
		# if request.method == 'POST':
			# if not request.form['USERNAME'] or not request.form['OLDPASSWORD'] or not request.form['NEWPASSWORD'] or not request.form['CPASSWORD']:
				# flash('Please enter all the fields', 'error')
			# else:
				# passwords = password(request.form['USERNAME'], request.form['OLDPASSWORD'], request.form['NEWPASSWORD'], request.form['CPASSWORD'])
				# db.session.add(passwords)
				# db.session.commit()
				# flash('Record was successfully added')
				# return redirect(url_for('adminlogin'))
		# return render_template('password.html')	 
		
		
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
